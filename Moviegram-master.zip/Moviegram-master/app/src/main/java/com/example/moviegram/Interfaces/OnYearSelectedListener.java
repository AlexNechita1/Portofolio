// OnYearSelectedListener.java
package com.example.moviegram.Interfaces;

public interface OnYearSelectedListener {
    void onYearSelected(int year);
    void onYearUnselected(int year);
}
