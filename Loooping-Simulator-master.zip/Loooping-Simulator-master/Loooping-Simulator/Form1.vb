﻿Imports System.Windows.Forms

Public Class Form1
    Inherits Form ' inherit from Form

    Private WithEvents Timer1 As New Timer

    Private Const speed As Integer = 5
    Private pressedKeys As New HashSet(Of Keys)

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        ' Add the pressed key to the set of pressed keys
        pressedKeys.Add(e.KeyCode)
    End Sub

    Private Sub Form1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        ' Remove the released key from the set of pressed keys
        pressedKeys.Remove(e.KeyCode)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ' Move the game object in the direction of all currently pressed keys
        Dim dx As Integer = 0
        Dim dy As Integer = 0
        For Each key In pressedKeys
            Select Case key
                Case Keys.W
                    dy -= speed
                Case Keys.S
                    dy += speed
                Case Keys.A
                    dx -= speed
                Case Keys.D
                    dx += speed
            End Select
        Next
        PictureBox1.Left += dx
        PictureBox1.Top += dy
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitializeComponent() ' call InitializeComponent

        ' Start the timer that updates the game object's position
        Timer1.Interval = 10
        Timer1.Enabled = True
    End Sub
End Class
